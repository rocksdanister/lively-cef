# Web Fractal Clock

This is a web implementation of the Fractal Clock screensaver by Rob Mayoff found here: http://www.dqd.com/~mayoff/programs/FractalClock/

You can make this into your macos screensaver with [WebSaver](https://github.com/tlrobinson/WebSaver).

You can view the effect by going to https://cakenggt.github.io/web-fractal-clock/
